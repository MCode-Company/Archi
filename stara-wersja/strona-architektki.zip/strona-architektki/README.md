# Strona architektki – statyczny HTML

Czysty HTML + CSS + JS, bez builda. Otwórz `index.html` w przeglądarce
albo uruchom podgląd: `npx serve .`

## Struktura
- `index.html` – strona główna (hero, o mnie, usługi, portfolio z filtrem, proces, opinia, kontakt)
- `projekt.html` – szablon strony pojedynczej realizacji
- `css/style.css` – style; kolory i fonty w `:root`
- `js/main.js` – linki social media (obiekt `SOCIAL` na górze), filtr portfolio,
  fallback animacji dla Firefoksa, obsługa formularza (TODO: podłączyć wysyłkę)
- `img/` – tutaj wrzuć zdjęcia

## Zdjęcia
Każdy blok `.media` przyjmuje `<img>`. Zamień `<div class="media-layer parallax">…</div>`
na `<img class="parallax" src="img/plik.jpg" alt="opis">` – placeholder i podpis znikną same.
Klasa `parallax` = efekt paralaksy, bez niej zdjęcie stoi w miejscu.

## Do uzupełnienia
Wszystko w nawiasach kwadratowych `[...]`: nazwa studia, bio, ceny, dane kontaktowe, NIP,
opisy projektów, polityka prywatności.
